const {SITE_URL,verifyToken,tokenFor,sendEmail,escapeHtml,html}=require('../lib/shared');
module.exports=async function handler(req,res){
 const token=req.query?.token; const d=verifyToken(token);
 if(!d||!['approve','reject'].includes(d.decision)) return html(res,403,'Invalid or expired review link','Please submit a new enquiry if you need further assistance.');
 try{
  if(d.decision==='reject'){
   await sendEmail({to:d.email,subject:'Update on your enquiry — AKONDO GLOBAL WORLD',text:`Hello ${d.name},\n\nThank you for contacting AKONDO GLOBAL WORLD. Unfortunately, we are unable to accept your current request at this time. No document upload is required.\n\nRegards,\nAKONDO GLOBAL WORLD`,html:`<p>Hello ${escapeHtml(d.name)},</p><p>Thank you for contacting AKONDO GLOBAL WORLD. Unfortunately, we are unable to accept your current request at this time. No document upload is required.</p><p>Regards,<br>AKONDO GLOBAL WORLD</p>`});
   return html(res,200,'Request declined','A polite decline email has been sent to the applicant. No upload link was sent.');
  }
  const uploadToken=tokenFor({id:d.id,email:d.email,name:d.name,exp:Date.now()+72*60*60*1000,kind:'upload'});const url=`${SITE_URL}/upload.html?token=${encodeURIComponent(uploadToken)}`;
  await sendEmail({to:d.email,subject:'Your enquiry is approved — secure document upload link',text:`Hello ${d.name},\n\nYour enquiry has passed our initial review. Please use this private upload link within 72 hours: ${url}\n\nOnly upload documents requested by our team. This is not a visa approval or ticket confirmation.\n\nAKONDO GLOBAL WORLD`,html:`<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto"><h2>Your enquiry has passed initial review</h2><p>Hello ${escapeHtml(d.name)},</p><p>We can review your request further. Please use the private link below to upload the documents requested by our team.</p><p><a href="${url}" style="display:inline-block;background:#10294b;color:white;padding:13px 18px;border-radius:8px;text-decoration:none">Open secure upload page</a></p><p>This link expires in 72 hours. Do not share it with anyone. This is not a visa approval or ticket confirmation.</p><p>Regards,<br>AKONDO GLOBAL WORLD</p></div>`});
  return html(res,200,'Approved — upload link sent',`An email with a private document upload link has been sent to <b>${escapeHtml(d.email)}</b>. The link expires in 72 hours.`);
 }catch(e){console.error('review error',e.message);return html(res,500,'Email could not be sent','Check the email service configuration and try again.');}
};
