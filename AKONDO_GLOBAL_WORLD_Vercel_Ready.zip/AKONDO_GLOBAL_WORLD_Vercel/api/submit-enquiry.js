const {SITE_URL,tokenFor,sendEmail,escapeHtml,json}=require('../lib/shared');
module.exports=async function handler(req,res){
 if(req.method!=='POST') return json(res,405,{ok:false,error:'Method not allowed.'});
 try{
  let d=req.body||{}; if(typeof d==='string') { try { d=JSON.parse(d); } catch { return json(res,400,{ok:false,error:'Invalid request format.'}); } }
  if(d.website) return json(res,200,{ok:true});
  for(const k of ['service','country','fullName','email','phone','details']) if(!String(d[k]||'').trim()) return json(res,400,{ok:false,error:`Please complete the ${k} field.`});
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(d.email))) return json(res,400,{ok:false,error:'Please enter a valid email address.'});
  if(!process.env.OWNER_EMAIL||!process.env.APPROVAL_SECRET||!SITE_URL) return json(res,503,{ok:false,error:'The email workflow is not configured yet. Please contact the business directly.'});
  const id=`AGW-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2,7).toUpperCase()}`;
  const base={id,email:String(d.email).trim(),name:String(d.fullName).trim(),exp:Date.now()+7*24*60*60*1000};
  const approve=tokenFor({...base,decision:'approve'}),reject=tokenFor({...base,decision:'reject'});
  const approvalUrl=`${SITE_URL}/api/review-enquiry?token=${encodeURIComponent(approve)}`;
  const rejectionUrl=`${SITE_URL}/api/review-enquiry?token=${encodeURIComponent(reject)}`;
  const rows=[['Reference',id],['Service',d.service],['Request category',d.serviceCategory||'Not provided'],['Job / occupation category',d.workRole||'Not applicable'],['Destination country',d.country],['Departure',d.origin||'Not provided'],['Expected travel date',d.travelDate||'Not provided'],['Full name',d.fullName],['Email',d.email],['Phone / WhatsApp',d.phone],['Nationality',d.nationality||'Not provided'],['Details',d.details]];
  const table=rows.map(([k,v])=>`<tr><th align="left" style="padding:8px;border-bottom:1px solid #eee">${escapeHtml(k)}</th><td style="padding:8px;border-bottom:1px solid #eee">${escapeHtml(v)}</td></tr>`).join('');
  await sendEmail({to:process.env.OWNER_EMAIL,subject:`New website enquiry ${id} — ${d.service}`,text:`New enquiry ${id}\n\n${rows.map(([k,v])=>`${k}: ${v}`).join('\n')}\n\nApprove: ${approvalUrl}\nDecline: ${rejectionUrl}`,html:`<div style="font-family:Arial,sans-serif;max-width:700px;margin:auto"><h2>New AKONDO GLOBAL WORLD enquiry</h2><p>Review the request below. No documents have been requested or uploaded yet.</p><table style="border-collapse:collapse;width:100%">${table}</table><p style="margin-top:24px"><a href="${approvalUrl}" style="background:#126c54;color:white;padding:12px 18px;border-radius:7px;text-decoration:none;display:inline-block">APPROVE &amp; SEND PRIVATE UPLOAD LINK</a> &nbsp; <a href="${rejectionUrl}" style="background:#f0f2f6;color:#18253a;padding:12px 18px;border-radius:7px;text-decoration:none;display:inline-block">DECLINE REQUEST</a></p><p style="color:#68758a;font-size:12px">Review links expire in 7 days. The request is not stored in a website database.</p></div>`});
  return json(res,200,{ok:true,reference:id});
 }catch(e){console.error('submit-enquiry error',e.message);return json(res,500,{ok:false,error:'We could not send your enquiry. Please try again or contact us by email.'});}
};
