const formidable=require('formidable');const fs=require('node:fs/promises');
const {verifyToken,sendEmail,escapeHtml,json}=require('../lib/shared');
module.exports=async function handler(req,res){
 if(req.method!=='POST')return json(res,405,{ok:false,error:'Method not allowed.'});
 try{
  const form=formidable({multiples:true,keepExtensions:true,maxFileSize:3*1024*1024,maxTotalFileSize:3*1024*1024,maxFiles:8,allowEmptyFiles:false,filter:part=>['application/pdf','image/jpeg','image/png','image/webp'].includes(part.mimetype||'')});
  const [fields,filesObj]=await form.parse(req);
  const token=Array.isArray(fields.token)?fields.token[0]:fields.token;const d=verifyToken(String(token||''));
  if(!d||d.kind!=='upload')return json(res,403,{ok:false,error:'This upload link is invalid or expired. Please ask the business for a new link.'});
  let files=filesObj.documents||[];if(!Array.isArray(files))files=[files];files=files.filter(f=>f&&f.size>0);if(!files.length)return json(res,400,{ok:false,error:'Please select at least one PDF, JPG, PNG or WEBP document.'});
  let total=0;const attachments=[];
  for(const f of files){total+=f.size;if(total>3*1024*1024)return json(res,413,{ok:false,error:'Combined upload size exceeds 3 MB. Please upload smaller files.'});const content=await fs.readFile(f.filepath);attachments.push({filename:String(f.originalFilename||'document').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,100),content:content.toString('base64')});await fs.unlink(f.filepath).catch(()=>{});}
  const rawNote=fields.note;const note=String(Array.isArray(rawNote)?rawNote[0]||'':rawNote||'').slice(0,1000);
  await sendEmail({to:process.env.OWNER_EMAIL,subject:`Documents received — ${d.id} — ${d.name}`,text:`Approved enquiry: ${d.id}\nClient: ${d.name}\nClient email: ${d.email}\n\nClient note:\n${note||'No note provided'}\n\nUploaded documents are attached.`,html:`<h2>Documents received</h2><p><b>Reference:</b> ${escapeHtml(d.id)}<br><b>Client:</b> ${escapeHtml(d.name)}<br><b>Client email:</b> ${escapeHtml(d.email)}</p><p><b>Client note:</b><br>${escapeHtml(note||'No note provided')}</p><p>Uploaded documents are attached. Handle them securely and delete them when no longer needed.</p>`,attachments});
  await sendEmail({to:d.email,subject:'Documents received — AKONDO GLOBAL WORLD',text:`Hello ${d.name},\n\nWe have received your uploaded documents and forwarded them to our team. We will contact you after review.\n\nAKONDO GLOBAL WORLD`,html:`<p>Hello ${escapeHtml(d.name)},</p><p>We have received your uploaded documents and forwarded them to our team. We will contact you after review.</p><p>Regards,<br>AKONDO GLOBAL WORLD</p>`});
  return json(res,200,{ok:true});
 }catch(e){console.error('submit-documents error',e.message);const msg=String(e.message||'');if(/maxTotalFileSize|maxFileSize|larger than|size/i.test(msg))return json(res,413,{ok:false,error:'Combined upload size exceeds 3 MB. Please upload smaller files.'});return json(res,500,{ok:false,error:'Documents could not be forwarded. Please retry or contact the business.'});}
};
module.exports.config={api:{bodyParser:false}};
